import { useEffect, useRef } from "react";
import DataGridViewReact from "./components/Datagridviewreact";

const columns = [
  { key: "albumId", label: "Album ID", width: 70 },
  { key: "id", label: "ID", width: 50 },
  { key: "title", label: "Title", width: 500 },
  { key: "url", label: "URL", width: 300 },
  { key: "thumbnailUrl", label: "Thumb Nail URL", width: 300 },
];

function App() {
  const table = useRef<any>(null);

  const albumIdRef = useRef<HTMLInputElement>(null);
  const titleRef = useRef<HTMLInputElement>(null);

  const getselectedRowRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    fetch("https://jsonplaceholder.typicode.com/photos")
      .then((response) => response.json())
      .then((data) => {
        table.current.setData(data);
      });
  }, []);

  return (
    <div>
      <h1 style={{ color: "blue" }}>DATAGRIDVIEW REACT</h1>
      <div style={{ display: "flex", marginBottom: "25px" }}>
        <label style={{ width: "60px" }}>Search : </label>
        <input
          type="search"
          style={{ width: "500px" }}
          onKeyDown={(e) => {
            if (e.key === "Enter") {
              let link = "";
              if (e.currentTarget.value === "") {
                link = `https://jsonplaceholder.typicode.com/photos`;
              } else {
                link = `https://jsonplaceholder.typicode.com/photos?id=${e.currentTarget.value}`;
              }
              fetch(link)
                .then((response) => response.json())
                .then((data) => {
                  console.log(data);
                  table.current.setData(data);
                });
            }
          }}
        />
      </div>

      <div style={{ display: "flex", marginBottom: "5px" }}>
        <label style={{ width: "100px" }}> ID : </label>
        <input ref={albumIdRef} type="text" />
      </div>
      <div style={{ display: "flex" }}>
        <label style={{ width: "100px" }}>Title : </label>
        <input ref={titleRef} type="text" style={{ width: "500px" }} />
        <div style={{marginLeft:"50px" ,display:"flex",columnGap:"5px"}}>
          <button onClick={()=>{
              if(getselectedRowRef.current){
                getselectedRowRef.current.value = table.current.getSelectedRow()
              }
          }}>Get Selected Row Index</button>
          <input
            ref={getselectedRowRef}
            type="search"
            style={{ width: "100px" }}
          />
        </div>
      </div>
      <div
        style={{
          marginTop: "10px",
          width: "100%",
          position: "relative",
          flex: 1,
          display: "flex",
        }}
      >
        <DataGridViewReact
          ref={table}
          adjustVisibleRowCount={220}
          columns={columns}
          handleSelectionChange={(rowItm: any) => {
            if (rowItm) {
              if (albumIdRef.current) {
                albumIdRef.current.value = rowItm.id;
              }
              if (titleRef.current) {
                titleRef.current.value = rowItm.title;
              }
            } else {
              if (albumIdRef.current) {
                albumIdRef.current.value = "";
              }
              if (titleRef.current) {
                titleRef.current.value = "";
              }
            }
          }}
        />
      </div>
    </div>
  );
}

export default App;
